package com.shopnaill.azkaruk_muslim.background_notificationseee;

import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.support.annotation.Nullable;
import android.widget.Toast;

/**
 * Created by mohamed on 29/08/18.
 */

public class PutNotification extends Service {

    @Override
    public void onCreate() {
        super.onCreate();

    }


    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {

       Toast.makeText(getApplicationContext()," Notification Name ",Toast.LENGTH_LONG).show();

        return Service.START_STICKY;
    }


    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }



    @Override
    public void onDestroy() {

        super.onDestroy();
        Toast.makeText(this, "Service Destroy", Toast.LENGTH_LONG).show();
    }


    @Override
    public void onStart(Intent intent, int startId) {
        Toast.makeText(this, "ServiceClass.onStart()", Toast.LENGTH_LONG).show();
        super.onStart(intent, startId);
    }
}
