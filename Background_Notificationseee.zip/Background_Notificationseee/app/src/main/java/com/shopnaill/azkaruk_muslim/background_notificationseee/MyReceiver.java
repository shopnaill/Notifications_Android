package com.shopnaill.azkaruk_muslim.background_notificationseee;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class MyReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        Intent service = new Intent(context, PutNotification.class);
        context.startService(service);
    }
}
